package copl

import org.scalajs.dom.{UIEvent, document, window}
import org.scalajs.dom.html.{Div, Input, Paragraph}
import rescala.default
import rescala.default._
import rescala.extra.Tags._
import scalatags.JsDom.all._
import scalatags.JsDom.{Attr, TypedTag}


case class Chatline(author: String, message: String)

object ChatApp {
  def main(args: Array[String]): Unit = {
    val contents = getContents()
    document.body.replaceChild(contents.render, document.body.firstChild)
  }

  def getContents() = {

    val nameInput = input(placeholder := "Your Name")
    val (nameEvent, renderedName): (Event[String], Input) =
      RenderUtil.inputFieldHandler(nameInput, oninput, clear = false)

    val messageInput = input()
    val (messageEvent, renderedMessage): (Event[String], Input) =
      RenderUtil.inputFieldHandler(messageInput, onchange, clear = true)

    val nameSignal: Signal[String] = nameEvent.latest("<Nothing yet>")

    val chatline: Event[Chatline] = messageEvent.map { msg => Chatline(nameSignal.value, msg)}

    val history: Signal[List[Chatline]] = chatline.list()

    val chatDisplay = Signal.dynamic {
      val reversedHistory = history.value.reverse
      reversedHistory.map{ case Chatline(author, message) =>
        p( s"${author}: $message")
      }
    }

    div(div(chatDisplay.asModifierL), renderedName, renderedMessage)
  }

}
