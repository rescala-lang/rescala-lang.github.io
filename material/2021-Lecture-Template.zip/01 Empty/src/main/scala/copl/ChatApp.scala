package copl

import org.scalajs.dom.document
import org.scalajs.dom.UIEvent
import org.scalajs.dom.html.{Div, Input}
import rescala.default._
import rescala.extra.Tags._
import scalatags.JsDom
import scalatags.JsDom.all._
import scalatags.JsDom.{Attr, TypedTag}

// other files in the project assume this exists, but you can adapt it as necessary
case class Chatline()

object ChatApp {

}

